new hoverEffect({
	parent: document.querySelector('.distortion-1'),
	intensity: 0.2,
	image1: "./assets/img/forest.jpg",
	image2: "./assets/img/mount.jpg",
	displacementImage: "./assets/img/fluid.jpg"
});

new hoverEffect({
	parent: document.querySelector('.distortion-2'),
	intensity: 0.2,
	image1: "./assets/img/lake.jpg",
	image2: "./assets/img/desert.jpg",
	displacementImage: "./assets/img/fluid.jpg"
});
